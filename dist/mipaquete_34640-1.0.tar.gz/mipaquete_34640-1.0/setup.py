from setuptools import setup

setup(  name='mipaquete_34640',
        version='1.0',
        description='mi primer paquete redistribuible',
        author='la comi 34640',
        packages=['paquete34640']

)