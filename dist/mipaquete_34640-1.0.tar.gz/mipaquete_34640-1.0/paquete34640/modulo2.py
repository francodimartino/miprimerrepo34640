def funcionpaquete2():
    print("funcionpaquete2")
    